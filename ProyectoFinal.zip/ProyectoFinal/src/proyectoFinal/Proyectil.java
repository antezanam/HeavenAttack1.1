package proyectoFinal;

import javafx.scene.shape.Circle;

public class Proyectil extends Circle{

	private Avion avion;
	private double x;
	private double y;
	private boolean estado;

	public Proyectil(Avion avion) {
		x =- 100;
		y =- 100;
		this.setCenterX(x);
		this.setCenterY(y);
		this.setRadius(5);
		this.avion = avion;
		this.estado = false;
	}

	public void mover(double ancho, double alto) {
		y -= 10;
		this.verificar(y, alto);
		this.setCenterY(y);
	}

	private void verificar(double y2, double alto) {
		if(y2 < -this.getRadius()){
			this.setCenterX(-100);
			this.setCenterY(-100);
		}
	}

	public boolean getEstado() {
		return estado;
	}
	
	public void setEstado(){
		y = avion.getCenterY();
		x = avion.getCenterX();
		this.estado =! this.estado;
		this.setCenterX(x);
		this.setCenterY(y);
	}
}