package proyectoFinal;

import java.io.File;
import java.net.MalformedURLException;
import java.util.Random;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class Obstaculo2 extends Rectangle {

	private Random r;
	private int retraso;

	public Obstaculo2() {
		r = new Random();

		this.setX(-500);
		this.setY(-500);
		this.setWidth(10);
		this.setHeight(10);
	}

	public void mover(double ancho, double alto) throws MalformedURLException {
		if (retraso-- <= 0) {
			double y = this.getY();
			y += 0.09;

			if(y > alto)
				this.init(alto, ancho);
			else
				this.setY(y);
		}
	}

	public void init(double alto, double ancho) throws MalformedURLException { 
		double width = (150);
		double height = (680);
		double x = 532;
		double y = 0;
		
		retraso = (int) (r.nextInt((int) alto));
		
		File file = new File("img/montana1.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);
		
		this.setFill(new ImagePattern(img));
		this.setX(x);
		this.setY(y);
		this.setHeight(height);
		this.setWidth(width);
	}
}