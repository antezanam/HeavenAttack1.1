package proyectoFinal;

import java.net.MalformedURLException;

import javafx.scene.layout.Pane;

public class Obstaculos2 {

	private Obstaculo2[] obstaculos2;
	private boolean visible;

	public Obstaculos2(int n) {
		System.out.println("Constructor Obstaculos");
		
		obstaculos2 = new Obstaculo2[n];
		
		for (int i=0; i<n; i++)
			obstaculos2[i] = new Obstaculo2();
		visible = false;
	}
	
	public void add (Pane paneCancha) {
		for(int i=0; i<obstaculos2.length; i++)
			paneCancha.getChildren().add(obstaculos2[i]);
	}

	public void cambioEstado() {
		visible = true;
	}
	
	public boolean getEstado() {
		return visible;
	}
	
	public void mover (double ancho, double alto) throws MalformedURLException{
		for (int i=0; i<obstaculos2.length; i++)
			obstaculos2[i].mover(ancho, alto);
	}
	
	public void init (double ancho, double alto) throws MalformedURLException {
		for (int i=0; i<obstaculos2.length; i++)
		obstaculos2[i].init(ancho, alto);
	}
}
