package proyectoFinal;

import java.net.MalformedURLException;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.Pane;

public class MapaAnimationTimer extends AnimationTimer{

	private Pane paneCancha;
	private Proyectil proyectil;
	private Obstaculos obstaculos;
	private Obstaculos2 obstaculos2;
	private Ovnis ovnis;
	public MapaAnimationTimer(Pane paneCancha, Proyectil proyectil, Obstaculos obstaculos, Obstaculos2 obstaculos2, Ovnis ovnis) {
		this.paneCancha = paneCancha;
		this.proyectil = proyectil;
		this.obstaculos = obstaculos;
		this.obstaculos2 = obstaculos2;
		this.ovnis= ovnis;

	}

	@Override
	public void handle(long arg0) {
		if(proyectil.getEstado()){
			proyectil.mover(paneCancha.getWidth(), paneCancha.getHeight());
		}	

		if (obstaculos.getEstado()) {
			try {
				obstaculos.mover(paneCancha.getWidth(), paneCancha.getHeight());
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}

		if (obstaculos2.getEstado()) {
			try {
				obstaculos2.mover(paneCancha.getWidth(), paneCancha.getHeight());
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
		
		if(ovnis.getEstado()){
			try {
				ovnis.mover(paneCancha.getWidth(), paneCancha.getHeight(), 20);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}	
	}
}

