package proyectoFinal;

import java.io.File;
import java.net.MalformedURLException;
import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class Ovni extends Circle{

	private Random r;
	private double radio;
	private int retraso;

	public Ovni() {
		r = new Random();

		this.setCenterX(-100);
		this.setCenterY(-100);
		this.setRadius(radio);
	}

	public int getRetraso() {
		return retraso;
	}

	public void setRetraso(int retraso) {
		this.retraso = retraso;		
	}

	public void mover(double ancho, double alto, double radio, double velocidad) throws MalformedURLException {
		double y =  this.getCenterY();
		if(retraso >= 0);{
			y += 1+velocidad*0.1;
			this.setCenterY(y); 
		}
	}

	public void init(double ancho, double alto, double radio, double retraso) throws MalformedURLException {

		File file = new File("img/ovni.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);

		this.setFill(new ImagePattern(img));
		this.setCenterX(ancho);
		this.setCenterY(alto - retraso);
		this.setRadius(radio);
		retraso += radio*2; 

	}
}
