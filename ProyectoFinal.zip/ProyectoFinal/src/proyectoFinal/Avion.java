package proyectoFinal;

import javafx.scene.shape.Circle;

public class Avion extends Circle {

	public Avion() {

		super();
		this.setCenterX(350);
		this.setCenterY(600);
		this.setRadius(40);
	}
}