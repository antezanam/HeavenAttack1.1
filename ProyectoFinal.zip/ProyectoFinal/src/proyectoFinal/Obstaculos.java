package proyectoFinal;

import java.net.MalformedURLException;

import javafx.scene.layout.Pane;

public class Obstaculos {

	private Obstaculo[] obstaculos;
	private boolean visible;

	public Obstaculos(int n) {
		System.out.println("Constructor Obstaculos");
		
		obstaculos = new Obstaculo[n];
		
		for (int i=0; i<n; i++)
			obstaculos[i] = new Obstaculo();
		visible = false;
	}
	
	public void add (Pane paneCancha) {
		for(int i=0; i<obstaculos.length; i++)
			paneCancha.getChildren().add(obstaculos[i]);
	}

	public void cambioEstado() {
		visible = true;
	}
	
	public boolean getEstado() {
		return visible;
	}
	
	public void mover (double ancho, double alto) throws MalformedURLException{
		for (int i=0; i<obstaculos.length; i++)
			obstaculos[i].mover(ancho, alto);
	}
	
	public void init (double ancho, double alto) throws MalformedURLException {
		for (int i=0; i<obstaculos.length; i++)
		obstaculos[i].init(ancho, alto);
	}
}