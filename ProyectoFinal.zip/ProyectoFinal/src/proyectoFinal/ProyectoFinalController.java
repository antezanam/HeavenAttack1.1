package proyectoFinal;

import java.io.File;
import java.net.MalformedURLException;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

public class ProyectoFinalController {

	@FXML
	private Pane paneCancha;

	private Avion avion;
	private Proyectil proyectil[];
	private Obstaculos obstaculos;
	private Obstaculos2 obstaculos2;
	private Ovnis ovnis;
	private MapaAnimationTimer miTimer;
	private int b;

	@FXML
	public void initialize() throws MalformedURLException{

		Rectangle clip = new Rectangle(0, 0, 0, 0);
		clip.widthProperty().bind(paneCancha.widthProperty());
		clip.heightProperty().bind(paneCancha.heightProperty());
		paneCancha.setClip(clip);

		avion = new Avion();
		anadirImagenA();
		paneCancha.getChildren().add(avion);
		
		obstaculos = new Obstaculos(50);
		obstaculos.add(paneCancha);
		
		obstaculos2 = new Obstaculos2(50);
		obstaculos2.add(paneCancha);
		
		ovnis = new Ovnis(50);
		ovnis.add(paneCancha);
		
		

		proyectil = new Proyectil[1000];
		for(int n = 0; n<proyectil.length;n++){
			proyectil[n]= new Proyectil(avion);
			paneCancha.getChildren().add(proyectil[n]);
		}
		b=0;
				
		for(int s=0;s<1000;s++){
			miTimer = new MapaAnimationTimer(paneCancha, proyectil[s], obstaculos, obstaculos2, ovnis);
			miTimer.start();
		}
		
	

	}

	public void anadirImagenA() throws MalformedURLException {
		File fileA = new File("img/avion.png");
		String localUrlA = fileA.toURI().toURL().toString();
		Image imgAvion = new Image(localUrlA);
		avion.setFill(new ImagePattern(imgAvion));
	}

	@FXML
	public void botonSalir() {
		System.exit(0);
	}

	@FXML
	public void botonIniciar() throws MalformedURLException { 
		System.out.println("Boton Comenzar presionado");

		if (!obstaculos.getEstado()) {
			obstaculos.cambioEstado();
			obstaculos.init(paneCancha.getWidth(), paneCancha.getHeight());
		}
		
		if (!obstaculos2.getEstado()) {
			obstaculos2.cambioEstado();
			obstaculos2.init(paneCancha.getWidth(), paneCancha.getHeight());
		}
		
		if (!ovnis.getEstado()) {
			ovnis.cambiaEstado();
			ovnis.init(paneCancha.getWidth(), paneCancha.getHeight(), 20);
		}
		
	}

	@FXML
	public void keyMoveHnd(KeyEvent ke) {
		double x = avion.getCenterX();
		double y = avion.getCenterY();

		switch (ke.getCode()) {
		case LEFT:
			if (x >= 30){
				x-=8;
			}
			else {
				x = 30;	
			}
			break;
		case RIGHT:
			if (x <= 650){
				x+=8;
			}
			else {
				x = 650;	
			}
			break;
		case SPACE:
			proyectil[b].setEstado();
			b++;
			break;
		default:
			System.out.println("KeyMoveHnd:" + ke.getCode());
			break;
		}
		ke.consume();

		avion.setCenterX(x);
		avion.setCenterY(y);
	}
}