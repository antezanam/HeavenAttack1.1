package proyectoFinal;

import java.net.MalformedURLException;
import java.util.Random;

import javafx.scene.layout.Pane;

public class Ovnis {

	private Ovni ovnis[];
	private boolean visible;
	private double velocidad = 0;
	private double retraso = 0;
	private Random r;

	public Ovnis(int n) {
		System.out.println("Constructor Ovnis");
		r = new Random();
		ovnis = new Ovni[n];

		for (int i=0; i<n; i++)
			ovnis[i] = new Ovni();
		visible = false;
	}

	public void add(Pane paneCancha) {

		for (int i=0; i<ovnis.length; i++)
			paneCancha.getChildren().add(ovnis[i]);
	}

	public void cambiaEstado() {
		visible = true;
	}

	public boolean getEstado() {
		return visible;
	}

	public double getVelocidad() {
		return velocidad;
	}

	public void setVelocidad() {
		this.velocidad = velocidad;
	}

	public void mover(double ancho, double alto, double radio) throws MalformedURLException {

		velocidad += 0.01;
		for (int i=0; i<ovnis.length; i++) {
			retraso = 1;
			retraso ++;


			if(ovnis[i].getCenterY() >= 500) {
				ovnis[i].init(ovnis[i].getCenterX(), -radio*2, radio, retraso*r.nextInt(70)+r.nextInt(25));
			}
			else {
				ovnis[i].mover(ancho, alto, radio, velocidad);
			}

			if(Math.abs(ovnis[0].getCenterY()-ovnis[1].getCenterY())<=50) {
				if((Math.max(ovnis[0].getCenterY(),ovnis[1].getCenterY())) == ovnis[0].getCenterY()){
					ovnis[0].setCenterY(ovnis[0].getCenterY()-100);
				}
				else {
					ovnis[1].setCenterY(ovnis[1].getCenterY()-100);
				}
			}
			if (Math.abs(ovnis[1].getCenterY()-ovnis[2].getCenterY()) <=50){
				if((Math.max(ovnis[1].getCenterY(),ovnis[2].getCenterY())) == ovnis[1].getCenterY()){
					ovnis[1].setCenterY(ovnis[1].getCenterY()-(100+radio*2));
				}

				else {
					ovnis[2].setCenterY(ovnis[2].getCenterY()-(100+radio*2));
				}
			}

		}
	}

	public void init(double ancho, double alto, double radio) throws MalformedURLException {

		for (int i=0; i<ovnis.length; i++) {
			retraso = i;
			retraso++;
			
			switch(i) {
			case 0:
				ovnis[0].init(105, -80, radio, retraso*r.nextInt(15) + r.nextInt(25));
				break;
			case 1:	
				ovnis[0].init(265, -380, radio, retraso*r.nextInt(15) + r.nextInt(20));
				break;
			case 2:
				ovnis[0].init(425, -100, radio, retraso*r.nextInt(15) + r.nextInt(5));
				break;
			
			}
		}
			
	}
}
